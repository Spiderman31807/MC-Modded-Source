
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package spiderman.villager_breeding.init;

import spiderman.villager_breeding.world.inventory.VillagerInventoryMenu;
import spiderman.villager_breeding.VillagerBreedingPlusMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

public class VillagerBreedingPlusModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, VillagerBreedingPlusMod.MODID);
	public static final RegistryObject<MenuType<VillagerInventoryMenu>> VILLAGER_INVENTORY = REGISTRY.register("villager_inventory", () -> IForgeMenuType.create(VillagerInventoryMenu::new));
}
