package chunkbychunk;

import net.minecraftforge.network.NetworkHooks;

import io.netty.buffer.Unpooled;
import java.util.Optional;

import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.MenuProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

public class BorderUtils {
	public static PlayerVariables.Variables getVariables(Player player) {
		return player.getCapability(PlayerVariables.CAPABILITY, null).orElse(new PlayerVariables.Variables());
	}

	public static void toggleBorder(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		variables.borderData.enabled = !variables.borderData.enabled;
		displayToggleMessage(player, variables.borderData.enabled);
		variables.syncVariables(player);
	}

	public static void toggleBorder(Player player, boolean toggle) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		variables.borderData.enabled = toggle;
		displayToggleMessage(player, variables.borderData.enabled);
		variables.syncVariables(player);
	}

	public static void displayToggleMessage(Player player, boolean enabled) {
		if(player.level().isClientSide())
			return;
		
		Component message = Component.translatable("chunkbychunk.toggled");
		Component toggle = Component.translatable("chunkbychunk." + (enabled ? "on" : "off"));
		player.displayClientMessage(Component.literal(message.getString() + toggle.getString()), false);
	}

	public static void toggleMap(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.miniMap = !variables.miniMap;
		variables.syncVariables(player);
	}

	public static boolean useMap(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		return variables.miniMap;
	}

	public static void openManager(Player player) {
		if (player instanceof ServerPlayer serverPlayer) {
			BlockPos _bpos = player.blockPosition();
			BorderUtils.removePreviewCost(player);
			NetworkHooks.openScreen(serverPlayer, new MenuProvider() {
				@Override
				public Component getDisplayName() {
					return Component.literal("Manager");
				}

				@Override
				public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
					return new ManagerMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
				}
			}, _bpos);
		}
	}

	public static int getChunkCost(Player player, ChunkPos chunk) {
		int chunkSize = getChunkSize(player);
		double distance = getDistanceFromOrigin(player, chunk) / 4;
		double size = (chunkSize / 3) * distance;
		double value = Math.floor(size + 5);
		return (int)Math.min(value, 50);
	}

	public static double getDistanceFromOrigin(Player player, ChunkPos chunk) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		ChunkPos originChunk = variables.borderData.getOriginChunk();
		return variables.borderData.distance(originChunk.x, originChunk.z, chunk.x, chunk.z);
	}

	public static int getPreviewCost(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		return variables.previewCost;
	}

	public static void removePreviewCost(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.lastPreview = Optional.empty();
		variables.previewCost = -1;
		variables.syncVariables(player);
	}

	public static void previewChunkCost(Player player, ChunkPos chunk) {
		int cost = getChunkCost(player, chunk);
		PlayerVariables.Variables variables = getVariables(player);
		variables.lastPreview = Optional.of(chunk);
		variables.previewCost = cost;
		variables.syncVariables(player);
	}

	public static boolean isPreviewingChunk(Player player, ChunkPos chunk) {
		PlayerVariables.Variables variables = getVariables(player);
		if(variables.previewCost == -1)
			return false;
		if(variables.lastPreview.isEmpty())
			return false;
		return isSameChunk(variables.lastPreview.get(), chunk) && variables.previewCost == getChunkCost(player, chunk);
	}

	public static boolean isSameChunk(ChunkPos chunk1, ChunkPos chunk2) {
		if(chunk1.x != chunk2.x)
			return false;
		if(chunk1.z != chunk2.z)
			return false;
		return true;
	}

	public static void buyChunk(Player player, ChunkPos chunk) {
		int cost = getChunkCost(player, chunk);
		if(!isPreviewingChunk(player, chunk) && !player.isCreative()) {
			previewChunkCost(player, chunk);
		} else if(player.experienceLevel >= cost || player.isCreative()) {
			addChunk(player, chunk.getMiddleBlockX(), chunk.getMiddleBlockZ());
			if(!player.isCreative())
				player.experienceLevel -= cost;
			removePreviewCost(player);
		}
	}

	public static void addChunk(Player player, int x, int y) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		variables.borderData.addChunk(new ChunkPos(BlockPos.containing(x, 0, y)));
		variables.syncVariables(player);
	}

	public static void removeChunk(Player player, int x, int y) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		variables.borderData.removeChunk(new ChunkPos(BlockPos.containing(x, 0, y)));
		variables.syncVariables(player);
	}

	public static void removeAllChunks(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		variables.borderData.removeAllChunks();
		variables.syncVariables(player);
	}

	public static int getChunkSize(Player player) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		return variables.borderData.getChunks().size();
	}

	public static boolean hasChunk(Player player, ChunkPos chunk) {
		PlayerVariables.Variables variables = getVariables(player);
		variables.borderData.player = player;
		return variables.borderData.hasChunk(chunk);
	}

	public static ChunkPos getRelitiveChunk(Player player, int x, int z) {
		ChunkPos playerChunk = new ChunkPos(player.blockPosition());
		Direction direction = Direction.fromYRot(player.getYRot());
		int relitiveX = x;
		int relitiveZ = z;
		switch(direction) {
			case SOUTH:
				relitiveX *= -1;
				relitiveZ *= -1;
				break;
			case EAST:
				relitiveX = z * -1;
				relitiveZ = x;
				break;
			case WEST:
				relitiveX = z;
				relitiveZ = x * -1;
				break;
		}
		
		return new ChunkPos(playerChunk.x + relitiveX, playerChunk.z + relitiveZ);
	}

	public static boolean hasChunkRelitive(Player player, int x, int z) {
		return hasChunk(player, getRelitiveChunk(player, x, z));
	}

	public static boolean isAdjacentRelitive(Player player, int x, int z) {
		if(hasChunkRelitive(player, x + 1, z + 1))
			return true;
		if(hasChunkRelitive(player, x - 1, z - 1))
			return true;
		if(hasChunkRelitive(player, x + 1, z - 1))
			return true;
		if(hasChunkRelitive(player, x - 1, z + 1))
			return true;
		if(hasChunkRelitive(player, x, z + 1))
			return true;
		if(hasChunkRelitive(player, x, z - 1))
			return true;
		if(hasChunkRelitive(player, x + 1, z))
			return true;
		if(hasChunkRelitive(player, x - 1, z))
			return true;
		return false;
	}
}
