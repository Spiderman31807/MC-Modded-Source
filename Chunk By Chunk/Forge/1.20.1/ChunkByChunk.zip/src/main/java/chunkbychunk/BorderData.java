package chunkbychunk;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.lang.Math;

import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;

public class BorderData {
	public Map<ResourceKey<Level>, ChunkPos> OriginChunks = new HashMap();
	public Map<ResourceKey<Level>, ArrayList<ChunkPos>> Chunks = new HashMap();
	public boolean enabled = true;
	public Player player;
	
	public BorderData() {
	}

	public BorderData(Player player) {
		this.player = player;
		this.addChunk(new ChunkPos(player.blockPosition()));
	}

	public BorderData(BorderData copy) {
		this.OriginChunks = copy.OriginChunks;
		this.Chunks = copy.Chunks;
		this.enabled = copy.enabled;
	}

	public BorderData(CompoundTag tag) {
		if(tag.contains("toggle")) {
			this.enabled = tag.getBoolean("toggle");
			tag.remove("toggle");
		}
			
		for(String key : tag.getAllKeys()) {
			if(key.startsWith("Bounds:")) {
				this.loadBounds(key, tag.getCompound(key));
			} else if(key.startsWith("Origin:")) {
				this.loadOrigin(key, tag.getIntArray(key));
			}
		}
	}

	public CompoundTag saveTag() {
		CompoundTag tag = new CompoundTag();
		for(ResourceKey<Level> dimension : this.Chunks.keySet()) {
			tag.put("Bounds:" + dimension.location().getPath(), this.saveChunks(this.Chunks.get(dimension)));
		}
		
		for(ResourceKey<Level> dimension : this.OriginChunks.keySet()) {
			ChunkPos chunk = this.OriginChunks.get(dimension);
			int[] XZ = new int[] { chunk.x, chunk.z };
			tag.putIntArray("Origin:" + dimension.location().getPath(), XZ);
		}
		
		tag.putBoolean("toggle", this.enabled);
		return tag;
	}

	public CompoundTag saveChunks(ArrayList<ChunkPos> chunks) {
		CompoundTag compound = new CompoundTag();
		for(int idx = 0; idx < chunks.size(); idx++) {
			int[] XZ = new int[] { chunks.get(idx).x, chunks.get(idx).z };
			compound.putIntArray("Chunk" + idx, XZ);
		}
		return compound;
	}

	public void loadBounds(String path, CompoundTag ChunksTag) {
		ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(path.replace("Bounds:", "")));
		ArrayList<ChunkPos> chunks = new ArrayList();
		for(String key : ChunksTag.getAllKeys()) {
			int[] XZ = ChunksTag.getIntArray(key);
			chunks.add(new ChunkPos(XZ[0], XZ[1]));
		}

		this.Chunks.put(dimension, chunks);
	}

	public void loadOrigin(String path, int[] chunk) {
		ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(path.replace("Origin:", "")));
		this.OriginChunks.put(dimension, new ChunkPos(chunk[0], chunk[1]));
	}

	public void setChunks(ArrayList<ChunkPos> chunks) {
		if(chunks == null)
			return;
		ResourceKey<Level> dimension = this.player.level().dimension();
		this.Chunks.put(dimension, chunks);
	}

	public void addChunk(ChunkPos chunk) {
		if(chunk == null)
			return;
		ArrayList<ChunkPos> chunks = this.getChunks();
		if(!chunks.contains(chunk))
			chunks.add(chunk);
		this.setChunks(chunks);
		
		ResourceKey<Level> dimension = this.player.level().dimension();
		if(!this.OriginChunks.containsKey(dimension))
			this.OriginChunks.put(dimension, chunk);
	}

	public void removeChunk(ChunkPos chunk) {
		if(chunk == null)
			return;
		ArrayList<ChunkPos> chunks = this.getChunks();
		if(chunks.contains(chunk))
			chunks.remove(chunk);
		this.setChunks(chunks);
	}

	public void removeAllChunks() {
		this.Chunks = new HashMap();
		this.OriginChunks = new HashMap();
		this.addChunk(new ChunkPos(this.player.blockPosition()));
	}

	public ChunkPos getOriginChunk() {
		ResourceKey<Level> dimension = this.player.level().dimension();
		if(!this.Chunks.containsKey(dimension))
			return null;
		return this.OriginChunks.get(dimension);
	}

	public ArrayList<ChunkPos> getChunks() {
		ResourceKey<Level> dimension = this.player.level().dimension();
		if(!this.Chunks.containsKey(dimension))
			return new ArrayList();
		return this.Chunks.get(dimension);
	}

	public boolean hasChunk(ChunkPos chunk) {
		return this.getChunks().contains(chunk);
	}

	public boolean isWithinBounds(Entity entity) {
		return this.isWithinBounds(new ChunkPos(entity.blockPosition()));
	}

	public boolean isWithinBounds(BlockPos pos) {
		return this.isWithinBounds(new ChunkPos(pos));
	}

	public boolean isWithinBounds(ChunkPos chunk) {
		if(this.enabled == false)
			return true;
		if(chunk == null)
			return false;
		return this.getChunks().contains(chunk);
	}

	public void removeBorderEdgeMotion(Player player, double xPos, double zPos) {
		Vec3 delta = player.getDeltaMovement();
		double x = delta.x;
		double z = delta.z;
		
		if(player.getX() != xPos)
			x = xPos > player.getX() ? Math.min(delta.x, 0) : Math.max(delta.x, 0);
		if(player.getZ() != zPos)
			z = zPos > player.getZ() ? Math.min(delta.z, 0) : Math.max(delta.z, 0);
			
		Vec3 restrictedDelta = new Vec3(x, delta.y, z);
		player.setDeltaMovement(restrictedDelta);
	}

	public void putWithinBounds(Player player) {
		PlayerVariables.Variables variables = player.getCapability(PlayerVariables.CAPABILITY, null).orElse(new PlayerVariables.Variables());
		this.player = player;
		ResourceKey<Level> dimension = player.level().dimension();
		if(!this.Chunks.containsKey(dimension)) {
			this.addChunk(new ChunkPos(player.blockPosition()));
			return;
		}
		
		ChunkPos chunk = this.closestChunk(player);
		if(variables.lastChunk.isPresent())
			chunk = variables.lastChunk.get();
		if(chunk == null)
			return;
		
		ChunkPos playerChunk = new ChunkPos(player.blockPosition());
		double xPos = Math.min(chunk.getMaxBlockX() + 0.999, Math.max(player.getX(), chunk.getMinBlockX() + 0.001));
		double zPos = Math.min(chunk.getMaxBlockZ() + 0.999, Math.max(player.getZ(), chunk.getMinBlockZ() + 0.001));
		this.removeBorderEdgeMotion(player, xPos, zPos);
		player.setPosRaw(xPos, player.getY(), zPos);
	}

	public ChunkPos closestChunk(Player player) {
		Map<Double, ChunkPos> ChunkMap = new HashMap<>();
		Map<ChunkPos, Double> DistanceMap = new HashMap<>();
		for(ChunkPos chunk : this.getChunks()) {
			double distance = getDistance(player, chunk);
			DistanceMap.put(chunk, distance);
			ChunkMap.put(distance, chunk);
		}
		
		if(DistanceMap.isEmpty())
			return null;
			
		List<Double> distances = new ArrayList(DistanceMap.values());
		distances.sort(Double::compareTo);
		return ChunkMap.get(distances.get(0));
	}

	public double getDistance(Player player, ChunkPos chunk) {
		double distance1 = distance(player.getX(), player.getZ(), chunk.getMinBlockX(), chunk.getMinBlockZ());
		double distance2 = distance(player.getX(), player.getZ(), chunk.getMaxBlockX(), chunk.getMaxBlockZ());
		double distance3 = distance(player.getX(), player.getZ(), chunk.getMaxBlockX(), chunk.getMinBlockZ());
		double distance4 = distance(player.getX(), player.getZ(), chunk.getMinBlockX(), chunk.getMaxBlockZ());
		return Math.max(distance1, Math.max(distance2, Math.max(distance3, distance4)));
	}

	public double distance(double x1, double z1, double x2, double z2) {
		double x = x1 - x2;
		double z = z1 - z2;
		return (x * x) + (z * z);
	}
}
