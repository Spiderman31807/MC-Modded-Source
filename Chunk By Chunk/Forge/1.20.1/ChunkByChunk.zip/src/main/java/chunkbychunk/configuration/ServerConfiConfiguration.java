package chunkbychunk.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class ServerConfiConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENTITY_INTERACT;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENTITY_ATTACKDIRECT;
	public static final ForgeConfigSpec.ConfigValue<Boolean> ENTITY_ATTACK;
	public static final ForgeConfigSpec.ConfigValue<Boolean> BLOCK_BREAK;
	public static final ForgeConfigSpec.ConfigValue<Boolean> BLOCK_PLACE;
	public static final ForgeConfigSpec.ConfigValue<Boolean> BLOCK_INTERACT;
	static {
		BUILDER.push("Outside Chunk Area, Interactions");
		ENTITY_INTERACT = BUILDER.comment("Allows Players to interact with Entities outside the Chunk Area").define("Entity Right Click", false);
		ENTITY_ATTACKDIRECT = BUILDER.comment("Allows Players to attack Entities outside the Chunk Area with Melee/Direct damage").define("Entity Left Click (Direct)", false);
		ENTITY_ATTACK = BUILDER.comment("Allows Players to attack Entities outside the Chunk Area with Ranged/Indirect damage").define("Entity Left Click (Indirect)", true);
		BLOCK_BREAK = BUILDER.comment("Allows Players to break Blocks outside the Chunk Area").define("Block Destroy", false);
		BLOCK_PLACE = BUILDER.comment("Allows Players to place Blocks outside the Chunk Area").define("Block Place", false);
		BLOCK_INTERACT = BUILDER.comment("Allows Players to interact with Blocks outside the Chunk Area").define("Block Interact", false);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
