package chunkbychunk;

import chunkbychunk.configuration.ServerConfiConfiguration;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.TickEvent;

import java.util.Optional;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;

@Mod.EventBusSubscriber
public class PlayerOverrides {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Player player = event.player;
			PlayerVariables.Variables variables = player.getCapability(PlayerVariables.CAPABILITY, null).orElse(new PlayerVariables.Variables());
			if(variables.borderData == null || variables.borderData.Chunks.size() == 0)
				variables.borderData = new BorderData(player);
			variables.borderData.player = player;

			if(variables.lastChunk.isPresent() && !variables.borderData.hasChunk(variables.lastChunk.get()))
				variables.lastChunk = Optional.empty();
			
			if(variables.borderData.isWithinBounds(player)) {
				variables.lastChunk = Optional.of(new ChunkPos(player.blockPosition()));
			} else if(!player.isSpectator()) {
				variables.borderData.putWithinBounds(player);
			}
			
			variables.syncVariables(player);
		}
	}
	
	@SubscribeEvent
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		if(ServerConfiConfiguration.BLOCK_INTERACT.get())
			return;
		clickEvent(event);
	}
	
	@SubscribeEvent
	public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
		if(ServerConfiConfiguration.BLOCK_BREAK.get())
			return;
		clickEvent(event);
	}
	
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		DamageSource source = event.getSource();
		if(!source.isIndirect() && ServerConfiConfiguration.ENTITY_ATTACKDIRECT.get())
			return;
		if(source.isIndirect() && ServerConfiConfiguration.ENTITY_ATTACK.get())
			return;
			
		if(source.getDirectEntity() instanceof Player player) {
			if(source.isIndirect())
				return;
			BorderData border = getBorderData(player);
			BlockPos pos = event.getEntity().blockPosition();
			event.setCanceled(!border.isWithinBounds(pos));
		}
	}

	
	@SubscribeEvent
	public static void onRightClickEntity(PlayerInteractEvent.EntityInteract event) {
		if(ServerConfiConfiguration.ENTITY_INTERACT.get())
			return;
		clickEvent(event);
	}
	
	@SubscribeEvent
	public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
		Item item = event.getEntity().getItemInHand(event.getHand()).getItem();
		if(item instanceof BlockItem && ServerConfiConfiguration.BLOCK_PLACE.get())
			return;
		clickEvent(event);
	}

	public static void clickEvent(PlayerInteractEvent event) {
		Player player = event.getEntity();
		BorderData border = getBorderData(player);
		event.setCanceled(!border.isWithinBounds(event.getPos()));
	}

	public static BorderData getBorderData(Player player) {
		PlayerVariables.Variables variables = player.getCapability(PlayerVariables.CAPABILITY, null).orElse(new PlayerVariables.Variables());
		if(variables.borderData == null || variables.borderData.Chunks.size() == 0)
			variables.borderData = new BorderData(player);
		variables.borderData.player = player;
		variables.syncVariables(player);
		return variables.borderData;
	}
}
